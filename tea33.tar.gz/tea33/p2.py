import sys

f = open("input.txt", "r")
set1= set(f.readline().rstrip().split(' '))

print("Set 1: ",set1)
set2= set(f.readline().rstrip().split(' '))

print("Set 2: ",set2)
print("set1 intersection set2 = ", set1.intersection(set2))
print("set1 union set2 = ", set1.union(set2))
print("set1 - set2 = ", set1.difference(set2))
print("set1 -+ set2 = ", set1.symmetric_difference(set2))

