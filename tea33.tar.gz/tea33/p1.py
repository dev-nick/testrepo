def freq(str): 
	str=str.lower()
	list = str.split()  
	unique_words = set(list) 
      
	for words in unique_words : 
		print('Frequency of ', words , 'is :', list.count(words)) 
  
      
f=open("1.txt","r+")
str=f.read()
freq(str) 
f.close()

