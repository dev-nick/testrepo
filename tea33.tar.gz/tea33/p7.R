x<-scan()
print(x)

dat <- read.csv(file="~/tea33/Salaries.csv", header=TRUE, sep=",")
print(dat[,1:3])
