import matplotlib.pyplot as plt
import pandas as pd
df=pd.read_csv('iris.csv')
ax2 = df.hist(column=['sepal length','sepal width','petal width','petal length'], bins=25, grid=False, figsize=(12,8), color='#86bf91', zorder=2, rwidth=0.9)
plt.show(ax2)
x=input()
