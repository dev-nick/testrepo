from datetime import datetime
from dateutil.relativedelta import relativedelta
import sys

print("Today's date is: ",datetime.now(),end="\n\n")
a=datetime.now()
print("Enter birthdate (day-mo-yr) ")
(day,mo,yr)=map(int,sys.stdin.readline().split('-'))
b=datetime(yr,mo,day)
td=a-b
day2=(td.days%366)//31
month=(day2)%12
if mo==2 and day==29:
	day2+=4
print("Your age is: ",td.days//366," Years ",month+1," Months ",day2-2," Days ")
print(relativedelta(a,b))
