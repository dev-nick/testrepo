#write py program to load dataset and plot graphs.
#acces gamemedal dataset from 192.168.20.161:8000 using browser
#download all files from portal
#check if matpoltlib,pandas is installed 
#1.count total no of citiess
#list of top 5 countries scoring max medals
#plot graph of the same
#2.list of top 5 players who earn max gold medals.
#3.draw bar chart showing cmoparison of 5 countries with diff color bar for 3 type of medalss, group (subplots)
#obj: referrnces oand study res: 
#4.pychart of no o medals earned by all countires


import matplotlib.pyplot as plt
import pandas as pd
import csv
data=pd.read_csv('file.csv')

x=[]
y=[]



for row in data:
	x.append(float(row[8]))
	y.append(float(row[9]))

plt.plot(x,y, label='Loaded from file!')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Price vs No. of units sold')
plt.legend()
plt.show()

#prepocess data remove rows and cols

