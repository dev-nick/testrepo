'''a bakery shop is selling  10 diff products to customers.
items like cakes, biscuits,bread etc are sold by bakery.
the shop is selling products by online orders as well as to customers approaching at the store.
the shop owner wants to understand daily sales, recurring monthly , quarterly, half yearly and yearly sales
 as well as pattern of selling each bakery item
bakery owner wants to know  inventory status, demand and suply status as well as profit/loss report
 apply data analytics to help shopowner

'''



