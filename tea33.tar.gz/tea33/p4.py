word="qwertqwert"
guess=list('_' for i in range(len(word)))

lives=4
flag=0
while lives>0:
	x=input("Enter a character ")
	if word.find(x)==-1:
		lives-=1
		print("Lives = ",lives,end="\n\n")
		pass
	for i in range(len(word)):
		if x==word[i]:
			guess[i]=x

	print(' '.join(guess),end="\n\n")
		
	if ' '.join(guess).find('_')==-1:
		flag=1
		break

if flag==1:
	print("You win !!\n")
else:
	print("You lose :(\n")

