library(dplyr)

data<-mtcars

data
summarise(data)
summ

count(data[5])
